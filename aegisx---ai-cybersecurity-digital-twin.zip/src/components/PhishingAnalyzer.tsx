import React, { useState } from 'react';
import { Shield, AlertTriangle, CheckCircle2, ShieldAlert, Cpu, CornerDownRight, PlusCircle, Sparkles, AlertCircle } from 'lucide-react';
import { ThreatAnalysis } from '../types';
import { PRESET_PHISHING_TEMPLATES } from '../data';

interface AnalyzerProps {
  onBlockedThreat: (type: string, score: number) => void;
}

export default function PhishingAnalyzer({ onBlockedThreat }: AnalyzerProps) {
  const [content, setContent] = useState('');
  const [sourceUrl, setSourceUrl] = useState('');
  const [contextType, setContextType] = useState('Email');
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<ThreatAnalysis | null>(null);
  const [error, setError] = useState<string | null>(null);

  const performAnalysis = async (textToAnalyze: string, customContext = contextType, urlSource = sourceUrl) => {
    if (!textToAnalyze.trim()) return;
    setIsLoading(true);
    setError(null);
    setResult(null);

    try {
      const response = await fetch('/api/phishing-analyzer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          content: textToAnalyze,
          sourceUrl: urlSource,
          contextType: customContext
        })
      });

      const data = await response.json();
      if (response.ok || data.fallbackData) {
        // If it returns a fallback due to lack of key or API error, display the parsed response
        const assessment = data.fallbackData || data;
        setResult(assessment);
        if (assessment.riskTier === 'CRITICAL' || assessment.riskTier === 'SUSPICIOUS') {
          onBlockedThreat(assessment.threatType || "Phishing Vector", assessment.threatScore);
        }
      } else {
        throw new Error(data.error || "Failed to parse threat indicators.");
      }
    } catch (err: any) {
      console.error(err);
      setError("An error occurred during safety diagnostics. Check internet or key status.");
    } finally {
      setIsLoading(false);
    }
  };

  const handlePresetSelect = (preset: typeof PRESET_PHISHING_TEMPLATES[0]) => {
    setContent(preset.content);
    setContextType(preset.contentType);
    performAnalysis(preset.content, preset.contentType, '');
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    performAnalysis(content, contextType, sourceUrl);
  };

  const getRiskColor = (tier: string) => {
    switch (tier) {
      case 'SAFE': return 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20';
      case 'SUSPICIOUS': return 'text-amber-400 bg-amber-500/10 border-amber-500/20';
      case 'CRITICAL': return 'text-rose-400 bg-rose-500/10 border-rose-500/20';
      default: return 'text-slate-400 bg-slate-500/10 border-slate-500/20';
    }
  };

  const getDialColor = (score: number) => {
    if (score < 40) return 'stroke-emerald-400';
    if (score < 75) return 'stroke-amber-400';
    return 'stroke-rose-500';
  };

  return (
    <div className="p-4 md:p-8 space-y-8" id="phishing-analyzer-wrapper">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-semibold text-white font-sans flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-blue-400 animate-pulse" />
            Adaptive Phishing & Scam Auditor
          </h2>
          <p className="text-zinc-500 text-xs mt-1">
            Feed email content, suspicious web parameters, or text messages into the neural core for zero-day social threat mitigation.
          </p>
        </div>
      </div>

      {/* Preset cards to let users test instantly */}
      <div>
        <span className="block text-[10px] font-mono tracking-wider text-zinc-500 uppercase font-semibold mb-2.5">
          QUICK SIMULATION PRESETS
        </span>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {PRESET_PHISHING_TEMPLATES.map((preset, idx) => (
            <button
              key={idx}
              onClick={() => handlePresetSelect(preset)}
              className="bg-zinc-900/30 border border-zinc-900 hover:border-blue-500/40 p-3.5 rounded-xl text-left transition-all hover:bg-zinc-900/60 flex items-start space-x-2.5 active:scale-95 cursor-pointer group"
            >
              <PlusCircle className="w-4 h-4 text-zinc-500 mt-0.5 flex-shrink-0 group-hover:text-blue-400" />
              <div className="overflow-hidden">
                <span className="block text-xs font-semibold text-white truncate">{preset.name}</span>
                <span className="text-[10px] font-mono text-blue-400 mt-1 block font-semibold">{preset.contentType}</span>
              </div>
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Input pane */}
        <div className="lg:col-span-7 bg-zinc-900/30 border border-zinc-900 rounded-3xl p-6 shadow-xl space-y-4" id="analyzer-input-card">
          <form onSubmit={handleFormSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold uppercase text-zinc-500 mb-1.5">Communication Type</label>
                <select
                  value={contextType}
                  onChange={(e) => setContextType(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-900 focus:border-blue-500 rounded-xl py-2.5 px-3 text-zinc-200 text-xs focus:outline-none transition-all cursor-pointer"
                >
                  <option value="Email">Phishing Email</option>
                  <option value="SMS Text">SMS Text (Smishing)</option>
                  <option value="Corporate Slack">Slack / Team Chat Message</option>
                  <option value="Web Form">Suspicious website text/contract</option>
                  <option value="Bank Statement">Unidentified ledger transaction</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold uppercase text-zinc-500 mb-1.5">Source URL / Sender ID (Optional)</label>
                <input
                  type="text"
                  placeholder="e.g. tracking-fedex-scam.com, security@paypiI.com"
                  value={sourceUrl}
                  onChange={(e) => setSourceUrl(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-900 focus:border-blue-500 rounded-xl py-2.5 px-3 text-zinc-200 text-xs focus:outline-none transition-all"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase text-zinc-500 mb-1.5">Paste Communication Content</label>
              <textarea
                placeholder="Ex. Dear Customer: Your electronic wallet needs authentication. Click here to confirm your passcodes or the profile will expire..."
                value={content}
                onChange={(e) => setContent(e.target.value)}
                className="w-full bg-zinc-950 border border-zinc-900 focus:border-blue-500 rounded-xl py-3.5 px-4 text-white text-xs focus:outline-none transition-all h-[180px] font-sans leading-relaxed"
                required
              />
            </div>

            <button
              type="submit"
              disabled={isLoading || !content.trim()}
              className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 disabled:from-zinc-900 disabled:to-zinc-900 text-white font-semibold text-xs py-3 px-4 rounded-xl flex items-center justify-center space-x-2 transition-all cursor-pointer shadow-md"
            >
              {isLoading ? (
                <>
                  <Cpu className="w-4 h-4 animate-spin" />
                  <span>Synthesizing zero-day threats...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Run Autonomous Threat Assessment</span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* AI report output pane */}
        <div className="lg:col-span-5 bg-zinc-900/30 border border-zinc-900 rounded-3xl p-6 shadow-xl min-h-[380px] flex flex-col justify-between" id="analyzer-result-panel">
          {isLoading && (
            <div className="flex-1 flex flex-col items-center justify-center py-12 space-y-3" id="loading-view">
              <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500" />
              <p className="text-zinc-500 text-xs animate-pulse">Querying server-side model nodes...</p>
            </div>
          )}

          {!isLoading && !result && !error && (
            <div className="flex-1 flex flex-col items-center justify-center text-center py-16 px-4 space-y-3.5" id="empty-state-view">
              <AlertCircle className="w-10 h-10 text-zinc-650" />
              <div>
                <h4 className="text-white text-sm font-semibold">Ready for Securing</h4>
                <p className="text-zinc-500 text-xs mt-1.5 max-w-xs mx-auto leading-relaxed">
                  Click on one of our simulation presets above, or paste your own message payload to receive real-time zero-day security assessments.
                </p>
              </div>
            </div>
          )}

          {error && (
            <div className="p-4 bg-rose-950/20 border border-rose-950 rounded-xl flex items-center space-x-2 text-rose-300 text-xs my-6" id="error-view">
              <AlertTriangle className="w-4 h-4 text-rose-400" />
              <span>{error}</span>
            </div>
          )}

          {result && (
            <div className="space-y-4" id="report-active-view">
              {/* Threat Dial Header */}
              <div className="flex items-center justify-between border-b border-zinc-900 pb-3.5">
                <div>
                  <span className="text-[10px] font-mono uppercase tracking-wider text-zinc-500 block">AI DIAGNOSTIC RESULT</span>
                  <p className="text-md font-bold text-white mt-0.5">{result.threatType}</p>
                </div>
                <div className={`px-2.5 py-1 text-[10px] uppercase font-mono tracking-wider font-semibold border rounded-full ${getRiskColor(result.riskTier)}`}>
                  {result.riskTier}
                </div>
              </div>

              {/* Score and Summary block */}
              <div className="flex items-start gap-4">
                {/* Score Dial */}
                <div className="relative w-16 h-16 flex items-center justify-center flex-shrink-0">
                  <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
                    <path
                      className="text-zinc-900"
                      strokeWidth="2.5"
                      stroke="currentColor"
                      fill="none"
                      d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    />
                    <path
                      className={`transition-all duration-1000 ${getDialColor(result.threatScore)}`}
                      strokeWidth="3"
                      strokeDasharray={`${result.threatScore}, 100`}
                      strokeLinecap="round"
                      fill="none"
                      d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    />
                  </svg>
                  <div className="absolute font-mono text-sm font-bold text-white">{result.threatScore}</div>
                </div>
                <div>
                  <h4 className="text-xs text-zinc-500 font-semibold mb-0.5">VULNERABILITY INDEX</h4>
                  <p className="text-zinc-300 text-xs leading-relaxed font-sans">{result.riskSummary}</p>
                </div>
              </div>

              {/* Red Flags spotted */}
              <div className="space-y-1.5">
                <span className="block text-[10px] font-mono uppercase tracking-wider text-zinc-500 font-bold">Tactical Red Flags Spotted</span>
                <div className="space-y-1 bg-zinc-950 p-3 rounded-xl border border-zinc-900 max-h-[110px] overflow-y-auto">
                  {result.redFlags.map((flag, i) => (
                    <div key={i} className="flex items-start space-x-1.5 text-[11px] text-zinc-300">
                      <span className="text-rose-400 font-bold mt-0.5">•</span>
                      <span>{flag}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action and Educational content */}
              <div className="space-y-4 pt-2">
                <div className="space-y-2">
                  <span className="block text-[10px] font-mono uppercase tracking-wider text-zinc-500 font-bold">Autonomous Direct Actions</span>
                  <div className="space-y-1.5">
                    {result.actionableAdvice.map((advice, i) => (
                      <div key={i} className="flex items-start space-x-2 text-[11px] text-zinc-300 leading-normal">
                        <CheckCircle2 className="w-3.5 h-3.5 text-blue-400 mt-0.5 flex-shrink-0" />
                        <span>{advice}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-gradient-to-r from-blue-600/10 to-indigo-600/10 border border-blue-500/20 p-3.5 rounded-xl text-zinc-400 text-[10px] leading-relaxed flex items-start space-x-2">
                  <Cpu className="w-3.5 h-3.5 text-blue-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <span className="font-semibold text-blue-300">Educational Mechanism: </span>
                    {result.educationalConcept}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
