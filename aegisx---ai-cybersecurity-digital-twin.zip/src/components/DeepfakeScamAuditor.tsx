import React, { useState } from 'react';
import { Radio, AlertTriangle, CheckCircle2, Volume2, ShieldCheck, Sparkles, Cpu, Plus, HelpCircle } from 'lucide-react';
import { DeepfakeAnalysis } from '../types';
import { PRESET_DEEPFAKE_TEMPLATES } from '../data';

interface AuditorProps {
  onBlockedThreat: (type: string, score: number) => void;
}

export default function DeepfakeScamAuditor({ onBlockedThreat }: AuditorProps) {
  const [description, setDescription] = useState('');
  const [callerToneInfo, setCallerToneInfo] = useState('robotic, urgent, static background');
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<DeepfakeAnalysis | null>(null);
  const [error, setError] = useState<string | null>(null);

  const performAnalysis = async (dialogue: string, tone = callerToneInfo) => {
    if (!dialogue.trim()) return;
    setIsLoading(true);
    setError(null);
    setResult(null);

    try {
      const response = await fetch('/api/deepfake-analyzer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          dialogueTranscript: dialogue,
          callerToneInfo: tone
        })
      });

      const data = await response.json();
      if (response.ok || data.fallbackData) {
        const assessment = data.fallbackData || data;
        setResult(assessment);
        if (assessment.deepfakeProbability > 60) {
          onBlockedThreat("Deepfake Call Attempt", assessment.deepfakeProbability);
        }
      } else {
        throw new Error(data.error || "Failed to parse synthesized vocal signatures.");
      }
    } catch (err: any) {
      console.error(err);
      setError("An exception occurred during verification. Check your endpoint configuration.");
    } finally {
      setIsLoading(false);
    }
  };

  const handlePresetSelect = (preset: typeof PRESET_DEEPFAKE_TEMPLATES[0]) => {
    setDescription(preset.content);
    setCallerToneInfo(preset.description);
    performAnalysis(preset.content, preset.description);
  };

  return (
    <div className="p-4 md:p-8 space-y-8" id="deepfake-scam-auditor-root">
      <div>
        <h2 className="text-xl font-semibold text-white font-sans flex items-center gap-2">
          <Radio className="w-5 h-5 text-blue-400 animate-pulse" />
          Neural Deepfake & Voice Scam Auditor
        </h2>
        <p className="text-zinc-500 text-xs mt-1">
          Scrutinize unexpected distress voice recordings, robotic video feeds, or artificial phone orders using advanced predictive cognitive checks.
        </p>
      </div>

      {/* Quick Simulation Presets */}
      <div>
        <span className="block text-[10px] font-mono tracking-wider text-zinc-500 uppercase font-semibold mb-2.5">
          TEST INTERACTIVE CLONE SCENARIOS
        </span>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {PRESET_DEEPFAKE_TEMPLATES.map((preset, idx) => (
            <button
              key={idx}
              onClick={() => handlePresetSelect(preset)}
              className="bg-zinc-900/30 border border-zinc-900 hover:border-blue-500/40 p-3.5 rounded-xl text-left transition-all hover:bg-zinc-900/60 flex items-start space-x-2.5 active:scale-95 cursor-pointer group"
            >
              <Volume2 className="w-4 h-4 text-zinc-500 mt-1 flex-shrink-0 group-hover:text-blue-400" />
              <div className="overflow-hidden">
                <span className="block text-xs font-semibold text-white truncate">{preset.name}</span>
                <span className="block text-[10px] text-zinc-400 mt-1 truncate">{preset.description}</span>
              </div>
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Form panel */}
        <div className="lg:col-span-7 bg-zinc-900/30 border border-zinc-900 rounded-3xl p-6 shadow-xl space-y-4" id="deepfake-input-card">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              performAnalysis(description, callerToneInfo);
            }}
            className="space-y-4"
          >
            <div>
              <label className="block text-xs font-semibold uppercase text-zinc-500 mb-1.5">Acoustic / Visual Tone Characteristics</label>
              <input
                type="text"
                placeholder="Ex. Extremely robotic, flat cadence, static backdrop noise, high emotional panic"
                value={callerToneInfo}
                onChange={(e) => setCallerToneInfo(e.target.value)}
                className="w-full bg-zinc-950 border border-zinc-900 focus:border-blue-500 rounded-xl py-2.5 px-3 text-zinc-200 text-xs focus:outline-none transition-all"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase text-zinc-500 mb-1.5">Paste Call Dialogue or Video Description</label>
              <textarea
                placeholder="Paste transcript or detail: 'Mom? I got into a legal crash and I need money immediately' or describe the uncanny synthetic face movement..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full bg-zinc-950 border border-zinc-900 focus:border-blue-500 rounded-xl py-3.5 px-4 text-white text-xs focus:outline-none transition-all h-[155px] leading-relaxed font-sans"
                required
              />
            </div>

            <button
              type="submit"
              disabled={isLoading || !description.trim()}
              className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 disabled:from-zinc-900 disabled:to-zinc-900 text-white font-semibold text-xs py-3 px-4 rounded-xl flex items-center justify-center space-x-2 transition-all cursor-pointer shadow-md"
            >
              {isLoading ? (
                <>
                  <Cpu className="w-4 h-4 animate-spin" />
                  <span>Auditing synthesize markers...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Audit Vocal/Visual Clone Risk</span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* Results layout */}
        <div className="lg:col-span-5 bg-zinc-900/30 border border-zinc-900 rounded-3xl p-6 shadow-xl min-h-[360px] flex flex-col justify-between" id="deepfake-assessment-panel">
          {isLoading && (
            <div className="flex-1 flex flex-col items-center justify-center py-12 space-y-3" id="deepfake-loading-view">
              <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500" />
              <p className="text-zinc-500 text-xs animate-pulse">Running advanced frequency/script audits...</p>
            </div>
          )}

          {!isLoading && !result && !error && (
            <div className="flex-1 flex flex-col items-center justify-center text-center py-16 px-4 space-y-3.5" id="deepfake-empty-view">
              <Volume2 className="w-10 h-10 text-zinc-650" />
              <div>
                <h4 className="text-white text-sm font-semibold">Voice Authentication Ready</h4>
                <p className="text-zinc-500 text-xs mt-1.5 max-w-xs mx-auto leading-relaxed">
                  Submit caller dialogue transcripts or verify presets to analyze speech compression traits, coercive triggers, and authentication safety.
                </p>
              </div>
            </div>
          )}

          {error && (
            <div className="p-3 bg-rose-950/25 border border-rose-950/40 rounded-xl flex items-center space-x-2 text-rose-300 text-xs font-mono my-4" id="deepfake-error-view">
              <AlertTriangle className="w-4 h-4 text-rose-400 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {result && (
            <div className="space-y-4" id="deepfake-results-content">
              {/* Header */}
              <div className="flex items-center justify-between border-b border-zinc-900 pb-3">
                <div>
                  <span className="text-[10px] font-mono uppercase text-zinc-500 font-bold">SYNTHETIC ANALYSIS METRICS</span>
                  <p className="text-xs font-mono text-zinc-400 mt-1">Scam coercion: <span className="font-bold text-rose-400">{result.scamLikelihood}</span></p>
                </div>
                <div className="text-right">
                  <span className="text-[10px] font-mono uppercase text-zinc-500 block font-bold">CLONE RATIO</span>
                  <span className="text-lg font-bold text-rose-400 font-mono mt-0.5 block">{result.deepfakeProbability}%</span>
                </div>
              </div>

              {/* Severity bar */}
              <div className="space-y-1.5 pt-1">
                <div className="flex justify-between text-[11px] font-mono text-zinc-400">
                  <span>DEEPFAKE DETECTED PROBABILITY</span>
                  <span className={result.deepfakeProbability > 60 ? "text-rose-400 font-extrabold" : "text-emerald-400 font-bold"}>
                    {result.deepfakeProbability > 60 ? "CRITICAL RISK STATUS" : "LOW RISK STATUS"}
                  </span>
                </div>
                <div className="w-full h-1.5 bg-zinc-950 rounded-full overflow-hidden border border-zinc-900">
                  <div 
                    className={`h-full transition-all duration-700 ${
                      result.deepfakeProbability > 60 ? 'bg-rose-500' : 'bg-emerald-400'
                    }`} 
                    style={{ width: `${result.deepfakeProbability}%` }}
                  />
                </div>
              </div>

              {/* Cloning Signatures */}
              <div className="space-y-2 pt-1">
                <span className="block text-[10px] font-mono uppercase text-zinc-500 font-bold">Clone Signatures spotted</span>
                <div className="space-y-1 bg-zinc-950 p-3 rounded-xl border border-zinc-900 max-h-[100px] overflow-y-auto">
                  {result.cloningIndicators.map((ind, idx) => (
                    <div key={idx} className="flex items-start space-x-1.5 text-[11px] text-zinc-300">
                      <span className="text-amber-400 font-bold">•</span>
                      <span>{ind}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Coercion tactics */}
              <div className="space-y-2 pt-1">
                <span className="block text-[10px] font-mono uppercase text-zinc-500 font-bold">Psychological Manipulations</span>
                <div className="space-y-1">
                  {result.coercionTacticsSpotted.map((tact, idx) => (
                    <div key={idx} className="flex items-start space-x-1.5 text-[11px] text-zinc-400">
                      <span className="text-rose-400 font-bold mt-0.5">!</span>
                      <span>{tact}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Verification steps */}
              <div className="space-y-2.5 border-t border-zinc-900 pt-3.5">
                <span className="block text-[10px] font-mono uppercase text-zinc-500 font-bold">AegisX Safeguards</span>
                <div className="space-y-2">
                  {result.verificationCountersteps.map((counter, idx) => (
                    <div key={idx} className="flex items-start space-x-2 text-[11px] text-zinc-300 leading-normal">
                      <ShieldCheck className="w-3.5 h-3.5 text-blue-400 mt-0.5 flex-shrink-0" />
                      <span>{counter}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
