import React, { useState, useRef, useEffect } from 'react';
import { Shield, Send, User, Bot, Sparkles, Terminal, RefreshCw } from 'lucide-react';
import { ChatMessage, TwinProfile } from '../types';

interface ChatProps {
  twinProfile: TwinProfile;
}

export default function TwinCoachChat({ twinProfile }: ChatProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isSending, setIsSending] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Initialize companion with an elegant greeting based on their custom profile details!
  useEffect(() => {
    const greeting = `Salutations! I am your AegisX Cybersecurity Digital Twin core. I have synthesized your base profile (Occupation: ${twinProfile.occupation}, Comfort Level: ${twinProfile.techSavviness}) and loaded direct monitoring parameters on your target channels (${twinProfile.devices.join(', ') || 'personal nodes'}). Ask me about security audits, malicious emails, or zero-day phishing indicators anytime. I am here to protect you.`;
    setMessages([
      {
        id: 'greet',
        sender: 'twin',
        text: greeting,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }
    ]);
  }, [twinProfile]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim() || isSending) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString() + '-u',
      sender: 'user',
      text: inputValue.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsSending(true);

    try {
      // Map turns to send to server
      const conversationHistory = messages.map(m => ({
        role: m.sender === 'user' ? 'user' : 'model',
        content: m.text
      }));

      const response = await fetch('/api/twin-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: userMessage.text,
          history: conversationHistory,
          twinProfile
        })
      });

      const data = await response.json();
      const twinReplyText = data.response;

      setMessages(prev => [
        ...prev,
        {
          id: Date.now().toString() + '-t',
          sender: 'twin',
          text: twinReplyText,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    } catch (err) {
      console.error(err);
      setMessages(prev => [
        ...prev,
        {
          id: Date.now().toString() + '-err',
          sender: 'twin',
          text: "I had a connection timeout while communicating with our threat neural arrays, but rest assured, your local AegisX active protection shields remain standard active. What else can I evaluate for you?",
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="p-4 md:p-8 h-[calc(100vh-140px)] flex flex-col" id="twin-chat-container">
      {/* Upper info section */}
      <div className="flex items-center justify-between border-b border-zinc-900 pb-3.5 mb-4 flex-shrink-0">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-blue-600/10 flex items-center justify-center border border-blue-500/20">
            <Bot className="w-5 h-5 text-blue-400" />
          </div>
          <div>
            <h2 className="text-sm font-semibold text-white">AI Twin Guardian Consultation Core</h2>
            <p className="text-[10px] text-zinc-500 font-mono mt-0.5">Status: <span className="text-blue-400 font-bold uppercase font-mono">Interactive (Stable)</span></p>
          </div>
        </div>
        <div className="hidden sm:flex text-right flex-col">
          <span className="text-[10px] font-mono text-zinc-650 tracking-wider font-semibold uppercase">DASHBOARD INTEGRATED SYNAPSE</span>
          <span className="text-[9px] font-mono text-blue-400 font-bold mt-0.5">{twinProfile.occupation} mode</span>
        </div>
      </div>

      {/* Message space */}
      <div className="flex-1 bg-zinc-950/80 border border-zinc-900 rounded-3xl p-5 overflow-y-auto space-y-4 mb-4" id="chat-scroller">
        {messages.map((msg) => {
          const isTwin = msg.sender === 'twin';
          return (
            <div
              key={msg.id}
              className={`flex items-start gap-3 max-w-[85%] ${isTwin ? 'mr-auto text-left' : 'ml-auto flex-row-reverse text-right'}`}
            >
              {/* Avatar */}
              <div className={`w-8 h-8 rounded-xl flex-shrink-0 flex items-center justify-center border ${
                isTwin ? 'bg-blue-500/10 border-blue-500/30 text-blue-400' : 'bg-zinc-900 border-zinc-800 text-zinc-300'
              }`}>
                {isTwin ? <Bot className="w-4 h-4" /> : <User className="w-4 h-4" />}
              </div>

              {/* Text Balloon */}
              <div className="space-y-1">
                <div className={`rounded-2xl px-4 py-3 text-xs inline-block leading-relaxed whitespace-pre-wrap ${
                  isTwin 
                    ? 'bg-zinc-900/60 text-zinc-200 border border-zinc-900 shadow-md' 
                    : 'bg-blue-600 text-white font-medium font-sans shadow-md'
                }`}>
                  {msg.text}
                </div>
                <div className="text-[9px] text-zinc-600 px-1 font-mono">
                  {msg.timestamp}
                </div>
              </div>
            </div>
          );
        })}

        {isSending && (
          <div className="flex items-start gap-3 mr-auto text-left max-w-[85%]" id="twin-chat-dots">
            <div className="w-8 h-8 rounded-xl flex-shrink-0 flex items-center justify-center border bg-blue-500/10 border-blue-500/30 text-blue-400">
              <Bot className="w-4 h-4 animate-spin" />
            </div>
            <div className="bg-zinc-900 text-zinc-400 border border-zinc-900 rounded-xl px-4 py-3 text-xs flex items-center space-x-2 shadow-md">
              <RefreshCw className="w-3.5 h-3.5 animate-spin text-blue-400" />
              <span className="animate-pulse">AegisX Twin mapping parameters...</span>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input container */}
      <form onSubmit={handleSendMessage} className="flex gap-2.5 flex-shrink-0 text-xs" id="chat-form">
        <input
          type="text"
          placeholder="Ask AegisX: 'How can I secure my Android devices?' or 'Is this text about unusual PayPal transactions toxic?'..."
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          disabled={isSending}
          className="flex-1 bg-zinc-950 border border-zinc-900 focus:border-blue-500 rounded-xl py-3.5 px-4 text-white placeholder-zinc-600 focus:outline-none transition-all"
          required
        />
        <button
          type="submit"
          disabled={isSending || !inputValue.trim()}
          className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 disabled:from-zinc-900 disabled:to-zinc-900 text-white px-5 rounded-xl flex items-center justify-center transition-all cursor-pointer shadow-md"
        >
          <Send className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
}
