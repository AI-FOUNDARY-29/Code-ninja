import React, { useState } from 'react';
import { Eye, ShieldAlert, Cpu, Check, AlertTriangle, HelpCircle, Lock, Server, RefreshCw } from 'lucide-react';
import { LeakScanResult } from '../types';

export default function DarkWebMonitor() {
  const [targetHandle, setTargetHandle] = useState('');
  const [handleType, setHandleType] = useState<'email' | 'phone' | 'username'>('email');
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<LeakScanResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleScan = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetHandle.trim()) return;

    setIsLoading(true);
    setError(null);
    setResult(null);

    try {
      const response = await fetch('/api/leak-scanner', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          targetHandle: targetHandle.trim(),
          handleType
        })
      });

      const data = await response.json();
      if (response.ok || data.fallbackData) {
        setResult(data.fallbackData || data);
      } else {
        throw new Error(data.error || "Failed to establish security credential index.");
      }
    } catch (err: any) {
      console.error(err);
      setError("An exception occurred during dark web scanner handshakes.");
    } finally {
      setIsLoading(false);
    }
  };

  const getSeverityBadge = (sev: string) => {
    switch (sev) {
      case 'SECURE': return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20';
      case 'LOW': return 'bg-blue-500/10 text-blue-400 border-blue-500/20';
      case 'MODERATE': return 'bg-amber-500/10 text-amber-400 border-amber-500/20';
      case 'CRITICAL': return 'bg-rose-500/10 text-rose-400 border-rose-500/20';
      default: return 'bg-slate-500/10 text-slate-400 border-slate-500/20';
    }
  };

  return (
    <div className="p-4 md:p-8 space-y-8" id="dark-web-monitor-root">
      <div>
        <h2 className="text-xl font-semibold text-white font-sans flex items-center gap-2">
          <Eye className="w-5 h-5 text-blue-400 animate-pulse" />
          Autonomous Dark Web Identity Scanner
        </h2>
        <p className="text-zinc-500 text-xs mt-1">
          Perform a non-invasive intelligence audit to cross-examine compromised credential leaks, social exposure logs, and dark web dumps.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Input card */}
        <div className="lg:col-span-5 bg-zinc-900/30 border border-zinc-900 rounded-3xl p-6 shadow-xl space-y-4" id="monitor-search-card">
          <div className="p-3.5 bg-blue-600/10 border border-blue-500/10 rounded-xl flex items-start space-x-2.5">
            <Lock className="w-4 h-4 text-blue-400 mt-0.5 flex-shrink-0" />
            <p className="text-[11px] text-zinc-400 leading-relaxed">
              AegisX leverages predictive scanning to audit credential leaks on global corporate structures. We do not inspect real raw servers or expose real credentials.
            </p>
          </div>

          <form onSubmit={handleScan} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold uppercase text-zinc-500 mb-1.5">Identifier Class</label>
              <div className="grid grid-cols-3 gap-2">
                {(['email', 'phone', 'username'] as const).map((type) => (
                  <button
                    key={type}
                    type="button"
                    onClick={() => setHandleType(type)}
                    className={`py-2 px-1.5 border rounded-xl text-[10px] uppercase font-mono transition-all font-bold cursor-pointer ${
                      handleType === type
                        ? 'bg-blue-500/15 text-blue-300 border-blue-500/30'
                        : 'bg-zinc-950 border-zinc-900 hover:border-zinc-800 text-zinc-400'
                    }`}
                  >
                    {type}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase text-zinc-500 mb-1.5">Enter Target Credential</label>
              <input
                type={handleType === 'email' ? 'email' : 'text'}
                placeholder={
                  handleType === 'email' ? 'e.g. user@gmail.com' :
                  handleType === 'phone' ? 'e.g. +14155552671' : 'e.g. gamerName_99'
                }
                value={targetHandle}
                onChange={(e) => setTargetHandle(e.target.value)}
                className="w-full bg-zinc-950 border border-zinc-900 focus:border-blue-500 rounded-xl py-2.5 px-3.5 text-white text-xs focus:outline-none transition-all font-mono"
                required
              />
            </div>

            <button
              type="submit"
              disabled={isLoading || !targetHandle.trim()}
              className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 disabled:from-zinc-900 disabled:to-zinc-900 text-white font-semibold text-xs py-3 px-4 rounded-xl flex items-center justify-center space-x-2 transition-all cursor-pointer shadow-lg shadow-blue-500/10"
            >
              {isLoading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Auditing credential directories...</span>
                </>
              ) : (
                <>
                  <Server className="w-4 h-4" />
                  <span>Scan Dark Web Exposures</span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* Right Output details */}
        <div className="lg:col-span-7 bg-zinc-900/30 border border-zinc-900 rounded-3xl p-6 shadow-xl min-h-[310px] flex flex-col justify-between animate-fade-in" id="monitor-report-pane">
          {isLoading && (
            <div className="flex-1 flex flex-col items-center justify-center py-12 space-y-3" id="monitor-loading">
              <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500" />
              <p className="text-zinc-500 text-xs animate-pulse">Filtering distributed search dumps...</p>
            </div>
          )}

          {!isLoading && !result && !error && (
            <div className="flex-1 flex flex-col items-center justify-center text-center py-16 px-4 space-y-4" id="monitor-empty">
              <Server className="w-10 h-10 text-zinc-650" />
              <div>
                <h4 className="text-white text-sm font-semibold">Scanning Engine Operational</h4>
                <p className="text-zinc-500 text-xs mt-1.5 max-w-sm mx-auto leading-relaxed">
                  Type an active credential handle to map historical leak severities and view credential exposure remediation details.
                </p>
              </div>
            </div>
          )}

          {error && (
            <div className="p-3 bg-rose-950/20 border border-rose-950 rounded-xl flex items-center space-x-2 text-rose-300 text-xs font-mono my-4" id="monitor-error">
              <AlertTriangle className="w-4 h-4 text-rose-400 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {result && (
            <div className="space-y-4" id="monitor-results-panel">
              <div className="flex items-center justify-between border-b border-zinc-900 pb-3.5">
                <div>
                  <span className="text-[10px] font-mono uppercase tracking-wider text-zinc-500 font-bold">TARGET ACCOUNT STATUS</span>
                  <p className="text-sm text-zinc-300 font-mono mt-0.5 break-all">{targetHandle}</p>
                </div>
                <div className={`px-2.5 py-1 text-[10px] font-bold font-mono tracking-wider border rounded-full ${getSeverityBadge(result.exposureSeverity)}`}>
                  {result.exposureSeverity}
                </div>
              </div>

              {/* Dial Info */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-zinc-950/40 p-3.5 rounded-xl border border-zinc-900">
                <div>
                  <span className="text-[10px] font-mono uppercase text-zinc-500 font-bold">Dark Web Listing Score</span>
                  <p className="text-2xl font-bold text-white font-mono mt-0.5">{result.darkWebPrevalence}<span className="text-xs text-zinc-600"> / 100</span></p>
                  <p className="text-[10px] text-zinc-400 leading-relaxed mt-1.5 font-normal">This represents predictive index metrics of listing density on dark web pasteboards.</p>
                </div>
                <div>
                  <span className="text-[10px] font-mono uppercase text-zinc-500 font-bold">Scanned Databases</span>
                  <p className="text-2xl font-bold text-blue-400 font-mono mt-0.5">
                    {result.breachesSpotted.length > 0 ? `${result.breachesSpotted.length} Spotted` : 'Clean'}
                  </p>
                  <p className="text-[10px] text-zinc-400 leading-relaxed mt-1.5 font-normal">Found in compiled leaks or credentials sharing listings.</p>
                </div>
              </div>

              {/* List of breaches */}
              {result.breachesSpotted.length > 0 ? (
                <div className="space-y-2">
                  <span className="block text-[10px] font-mono uppercase text-zinc-500 font-bold">Exposed Breach Incidents</span>
                  <div className="space-y-2 max-h-[140px] overflow-y-auto pr-1">
                    {result.breachesSpotted.map((breach, idx) => (
                      <div key={idx} className="bg-zinc-950 p-2.5 rounded-xl border border-zinc-900 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-1">
                        <div>
                          <span className="block text-xs font-semibold text-white">{breach.breachName}</span>
                          <div className="flex flex-wrap items-center gap-1.5 mt-1">
                            {breach.compromisedData.map((asset, i) => (
                              <span key={i} className="text-[9px] font-mono uppercase bg-rose-500/10 text-rose-300 border border-rose-500/20 px-1.5 py-0.5 rounded-sm font-semibold">
                                {asset}
                              </span>
                            ))}
                          </div>
                        </div>
                        <span className="text-[10px] font-mono text-zinc-500 self-start sm:self-center">{breach.date}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="p-3 bg-emerald-500/5 border border-emerald-500/10 rounded-xl text-emerald-300 text-xs">
                  No direct automated data matches listed in public database breaches. Make sure to keep multi-factor systems active!
                </div>
              )}

              {/* Direct Remedies */}
              <div className="space-y-2.5 border-t border-zinc-900 pt-4">
                <span className="block text-[10px] font-mono uppercase text-blue-400 font-bold">Dynamic Defensive Remedies</span>
                <div className="space-y-2">
                  {result.securityRecommendations.map((recom, idx) => (
                    <div key={idx} className="flex items-start space-x-2 text-[11px] text-zinc-300 leading-normal">
                      <Check className="w-3.5 h-3.5 text-blue-400 mt-0.5 flex-shrink-0" />
                      <span>{recom}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
