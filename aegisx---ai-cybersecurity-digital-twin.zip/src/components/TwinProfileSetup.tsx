import React, { useState, useEffect } from 'react';
import { Shield, Smartphone, Laptop, User, Check, Key, Eye, HelpCircle, RefreshCw, SunMoon, Contrast } from 'lucide-react';
import { TwinProfile } from '../types';

interface SetupProps {
  profile: TwinProfile;
  onUpdate: (profile: TwinProfile) => void;
  theme: string;
  onSetTheme: (theme: string) => void;
}

const DEVICE_PRESETS = [
  { id: 'dev-1', name: 'iPhone (iOS)', icon: Smartphone },
  { id: 'dev-2', name: 'Android Phone (Google)', icon: Smartphone },
  { id: 'dev-3', name: 'macOS Laptop/Desktop', icon: Laptop },
  { id: 'dev-4', name: 'Windows Laptop/Desktop', icon: Laptop },
  { id: 'dev-5', name: 'Google Chrome / Edge', icon: Shield },
];

const ISSUE_PRESETS = [
  "Phishing Emails / Smishing Messages",
  "Voice Cloning & Call Scams",
  "Deepfake Videos & Mimicry",
  "Financial Transaction Fraud",
  "Corporate Identity Harvesting",
  "Dark Web Leak Tracking",
  "Account Takeover via Weak Tokens"
];

export default function TwinProfileSetup({ profile, onUpdate, theme, onSetTheme }: SetupProps) {
  const [age, setAge] = useState(profile.age);
  const [occupation, setOccupation] = useState(profile.occupation);
  const [techSavviness, setTechSavviness] = useState<TwinProfile['techSavviness']>(profile.techSavviness);
  const [selectedDevices, setSelectedDevices] = useState<string[]>(profile.devices);
  const [selectedIssues, setSelectedIssues] = useState<string[]>(profile.concerns);
  const [syncProgress, setSyncProgress] = useState(100);
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncLogs, setSyncLogs] = useState<string[]>([
    "Digital Twin core activated.",
    "User digital footprints evaluated from setup data.",
    "Continuous AI guardian learning mode: STABLE."
  ]);

  const triggerSync = (updatedProfile: TwinProfile) => {
    setIsSyncing(true);
    setSyncProgress(15);
    setSyncLogs([
      "Initiating Digital Twin synchronization sequence...",
      `Loading customized profile behaviors: User is a ${updatedProfile.age}-year-old ${updatedProfile.occupation || 'User'}.`,
    ]);

    setTimeout(() => {
      setSyncProgress(45);
      setSyncLogs(prev => [
        ...prev,
        `Analyzing device nodes: ${updatedProfile.devices.join(', ') || 'No devices loaded'}.`,
        `Synthesizing custom countermeasures for concerns: ${updatedProfile.concerns.length} vulnerability models selected.`
      ]);
    }, 1000);

    setTimeout(() => {
      setSyncProgress(80);
      setSyncLogs(prev => [
        ...prev,
        "Simulating neural network convergence on normal daily transaction sequences...",
        "Evaluating defensive safe words and offline fallback parameters."
      ]);
    }, 2000);

    setTimeout(() => {
      setSyncProgress(100);
      setIsSyncing(false);
      setSyncLogs(prev => [
        ...prev,
        "Digital Twin AI model successfully converged! Continuous learning active."
      ]);
      onUpdate(updatedProfile);
    }, 3000);
  };

  const toggleDevice = (name: string) => {
    const updated = selectedDevices.includes(name)
      ? selectedDevices.filter(d => d !== name)
      : [...selectedDevices, name];
    setSelectedDevices(updated);
  };

  const toggleIssue = (name: string) => {
    const updated = selectedIssues.includes(name)
      ? selectedIssues.filter(i => i !== name)
      : [...selectedIssues, name];
    setSelectedIssues(updated);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: TwinProfile = {
      age,
      occupation,
      techSavviness,
      devices: selectedDevices,
      concerns: selectedIssues
    };
    triggerSync(updated);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 p-4 md:p-8" id="twin-profile-setup-container">
      {/* Left Column Form */}
      <div className="lg:col-span-7 bg-zinc-900/30 border border-zinc-900 rounded-3xl p-6 shadow-xl flex flex-col justify-between" id="setup-form-card">
        <div>
          <div className="flex items-center space-x-3 mb-6">
            <div className="w-10 h-10 rounded-xl bg-blue-600/10 flex items-center justify-center border border-blue-500/20">
              <User className="w-5 h-5 text-blue-400" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-white font-sans">Behavioral Base Profile</h2>
              <p className="text-zinc-500 text-xs mt-1">AegisX customizes defensive intelligence according to your specific profile parameters.</p>
            </div>
          </div>

          <form onSubmit={handleSave} className="space-y-6">
            {/* Row 1: Age & Occupation */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold uppercase text-zinc-500 mb-2">Age Group / Age</label>
                <input
                  type="number"
                  placeholder="e.g. 52"
                  value={age}
                  onChange={(e) => setAge(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-900 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 rounded-xl py-2.5 px-4 text-white text-sm focus:outline-none transition-all"
                  required
                />
              </div>
              <div>
                <label className="block text-xs font-semibold uppercase text-zinc-500 mb-2">Primary Occupation</label>
                <input
                  type="text"
                  placeholder="e.g. Financial Manager, Senior Citizen, Student"
                  value={occupation}
                  onChange={(e) => setOccupation(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-900 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 rounded-xl py-2.5 px-4 text-white text-sm focus:outline-none transition-all"
                  required
                />
              </div>
            </div>

            {/* Row 2: Tech Savviness */}
            <div>
              <label className="block text-xs font-semibold uppercase text-zinc-500 mb-2">Digital Comfort Level</label>
              <div className="grid grid-cols-3 gap-3">
                {(['Basic (Low)', 'Moderate', 'Advanced (Tech Person)'] as TwinProfile['techSavviness'][]).map((level) => (
                  <button
                    key={level}
                    type="button"
                    onClick={() => setTechSavviness(level)}
                    className={`py-2.5 px-3 rounded-xl border text-xs font-medium text-center transition-all cursor-pointer ${
                      techSavviness === level
                        ? 'bg-blue-500/10 text-blue-400 border-blue-500/40 shadow-inner'
                        : 'bg-zinc-950 border-zinc-900 hover:border-zinc-800 text-zinc-400'
                    }`}
                  >
                    {level}
                  </button>
                ))}
              </div>
            </div>

            {/* Row 3: Devices */}
            <div>
              <label className="block text-xs font-semibold uppercase text-zinc-500 mb-2">Connected Device Nodes</label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {DEVICE_PRESETS.map((device) => {
                  const Icon = device.icon;
                  const isChecked = selectedDevices.includes(device.name);
                  return (
                    <button
                      key={device.id}
                      type="button"
                      onClick={() => toggleDevice(device.name)}
                      className={`flex items-center space-x-2.5 p-3 rounded-xl border text-left transition-all cursor-pointer ${
                        isChecked
                          ? 'bg-blue-500/10 text-blue-400 border-blue-500/30'
                          : 'bg-zinc-950 border-zinc-900 hover:border-zinc-800 text-zinc-400'
                      }`}
                    >
                      <div className={`w-5 h-5 rounded-full flex items-center justify-center border ${
                        isChecked ? 'bg-blue-500/20 border-blue-400' : 'border-zinc-800 bg-[#050505]'
                      }`}>
                        {isChecked && <Check className="w-3 h-3 text-blue-400" />}
                      </div>
                      <span className="text-xs truncate">{device.name}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Row 4: Key Concerns */}
            <div>
              <label className="block text-xs font-semibold uppercase text-zinc-500 mb-2">Primary Target Vulnerabilities</label>
              <div className="space-y-2">
                {ISSUE_PRESETS.map((issue) => {
                  const isChecked = selectedIssues.includes(issue);
                  return (
                    <div
                      key={issue}
                      onClick={() => toggleIssue(issue)}
                      className="flex items-center justify-between p-3 rounded-xl bg-zinc-950 border border-zinc-900 hover:border-zinc-800 cursor-pointer transition-all select-none"
                    >
                      <span className="text-xs text-zinc-300 font-sans">{issue}</span>
                      <div className={`w-5 h-5 rounded border flex items-center justify-center transition-all ${
                        isChecked ? 'bg-blue-500/15 border-blue-500' : 'border-zinc-900 bg-[#050505]'
                      }`}>
                        {isChecked && <div className="w-2.5 h-2.5 rounded-sm bg-blue-400" />}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Sync Submit */}
            <div className="pt-2">
              <button
                type="submit"
                disabled={isSyncing}
                className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 disabled:bg-zinc-900 disabled:text-zinc-600 text-white font-semibold text-sm py-3 px-4 rounded-xl flex items-center justify-center space-x-2 transition-all cursor-pointer shadow-lg shadow-blue-500/10"
              >
                {isSyncing ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Syncing Security Engine...</span>
                  </>
                ) : (
                  <>
                    <Shield className="w-4 h-4" />
                    <span>Synchronize AI Twin Model</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* Right Column Visualization */}
      <div className="lg:col-span-5 flex flex-col gap-6" id="twin-visualization-column">
        {/* Hologram Box */}
        <div className="bg-zinc-900/30 border border-zinc-900 rounded-3xl p-6 shadow-xl text-center relative overflow-hidden flex flex-col justify-between h-[350px]" id="twin-hologram-card">
          <div className="absolute top-4 right-4 flex items-center space-x-1.5 px-3 py-1 bg-blue-500/10 rounded-full border border-blue-500/20">
            <span className={`w-2 h-2 rounded-full ${isSyncing ? 'bg-amber-400 animate-pulse' : 'bg-emerald-400'}`} />
            <span className="text-[10px] text-blue-400 uppercase font-mono tracking-wider font-semibold">
              {isSyncing ? 'Syncing core...' : 'Secured Normalcy'}
            </span>
          </div>

          <div className="mt-8 flex flex-col items-center">
            {/* Hexagon/Circle Twin Visualizer */}
            <div className="relative w-28 h-28 mb-4 flex items-center justify-center">
              {/* Outer Pulse Rings */}
              <div className={`absolute inset-0 rounded-full border border-blue-500/20 ${isSyncing ? 'animate-ping' : 'animate-pulse'}`} />
              <div className="absolute inset-2 rounded-full border border-indigo-500/15 animate-spin" style={{ animationDuration: '6s' }} />
              
              <div className="w-20 h-20 rounded-full bg-zinc-950 border-2 border-blue-500 flex flex-col items-center justify-center shadow-lg shadow-blue-500/20">
                <Shield className="w-7 h-7 text-blue-400 mb-0.5 animate-pulse" />
                <span className="text-[9px] text-zinc-500 font-mono">AegisX_A1</span>
              </div>
            </div>

            <h3 className="text-white font-semibold font-sans">Behavioral Digital Twin</h3>
            <p className="text-zinc-400 text-xs mt-1.5 px-4 max-w-sm leading-relaxed">
              Your autonomous shadow twin learns what behaviors look normal to neutralize anomalous fraud payloads proactively.
            </p>
          </div>

          {/* Sync status slider */}
          <div className="w-full mt-4">
            <div className="flex justify-between items-center text-[10px] font-mono mb-1.5 px-1">
              <span className="text-zinc-500">MODEL REINFORCEMENT SPEED</span>
              <span className="text-blue-400 font-bold">{syncProgress}%</span>
            </div>
            <div className="w-full h-1.5 bg-zinc-950 rounded-full overflow-hidden border border-zinc-900">
              <div 
                className="h-full bg-gradient-to-r from-blue-500 to-indigo-500 transition-all duration-300" 
                style={{ width: `${syncProgress}%` }}
              />
            </div>
          </div>
        </div>

        {/* --- DEDICATED ACCESSIBILITY SETTINGS CARD --- */}
        <div className="bg-zinc-900/30 border border-zinc-900 rounded-3xl p-6 shadow-xl space-y-4" id="accessibility-preferences-card">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 rounded-lg bg-blue-500/10 flex items-center justify-center border border-blue-500/20">
              <SunMoon className="w-4 h-4 text-blue-400" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-white font-sans">Accessibility Display Settings</h3>
              <p className="text-[10px] text-zinc-500 font-mono">Personalize contrast & legibility offsets</p>
            </div>
          </div>

          <div className="space-y-2.5">
            <span className="block text-[10px] font-mono uppercase text-zinc-500 font-bold">Contrast Preference</span>
            
            <div className="grid grid-cols-1 gap-2">
              {[
                { id: 'deepspace', name: 'Deep Cosmic Dark (Default)', desc: 'Refined twilight backdrop with subtle cyber blue borders', icon: Shield },
                { id: 'highcontrast', name: 'High Contrast Mode (A11y)', desc: 'Pure black canvas with illuminated neon accents and maximum character legibility', icon: Contrast },
                { id: 'light', name: 'Cool Light Override', desc: 'Crisp off-white layouts and prominent charcoal content for daytime reading comfort', icon: SunMoon }
              ].map((themeOpt) => {
                const isSelected = theme === themeOpt.id;
                const OptIcon = themeOpt.icon;
                return (
                  <button
                    key={themeOpt.id}
                    type="button"
                    onClick={() => onSetTheme(themeOpt.id)}
                    className={`p-3 rounded-2xl border text-left flex items-start space-x-3 transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-blue-500/15 border-blue-500/80 text-white shadow-md'
                        : 'bg-zinc-950 border-zinc-900 hover:border-zinc-850 text-zinc-400'
                    }`}
                  >
                    <div className={`p-1.5 rounded-lg border ${isSelected ? 'bg-blue-500/10 border-blue-400 text-blue-400' : 'bg-zinc-900 border-zinc-800 text-zinc-500'} mt-0.5`}>
                      <OptIcon className="w-3.5 h-3.5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <span className="block text-xs font-bold leading-none">{themeOpt.name}</span>
                      <span className="block text-[10px] text-zinc-500 mt-1.5 leading-relaxed font-sans">{themeOpt.desc}</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Real-time sync logs console */}
        <div className="bg-zinc-950 border border-zinc-900 rounded-3xl p-5 shadow-xl flex-1 flex flex-col justify-between" id="twin-logs-terminal">
          <div>
            <div className="flex justify-between items-center mb-3">
              <span className="text-[11px] font-mono tracking-wider text-zinc-500 uppercase font-semibold">Learning Core logs (live)</span>
              <span className="text-[9px] font-mono text-zinc-650">Node: system_twin_092</span>
            </div>
            <div className="font-mono text-[11px] text-zinc-400 space-y-2 bg-zinc-900/40 p-3.5 rounded-xl border border-zinc-900/60 leading-relaxed max-h-[140px] overflow-y-auto">
              {syncLogs.map((log, index) => (
                <div key={index} className="flex items-start space-x-1.5">
                  <span className="text-blue-500">▶</span>
                  <span className="break-words">{log}</span>
                </div>
              ))}
            </div>
          </div>
          <p className="text-[10px] text-zinc-500 mt-4 italic leading-relaxed">
            *AegisX processes standard profiling parameters entirely inside the container and relies on server-safe Gemini parameters to map suspicious text. No real private credentials are ever transmitted out.
          </p>
        </div>
      </div>
    </div>
  );
}
