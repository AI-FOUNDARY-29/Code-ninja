import React, { useState } from 'react';
import { Shield, ShieldCheck, Zap, AlertTriangle, Play, HelpCircle, Check, X, ShieldAlert, BookOpen, AlertCircle, RefreshCw, Smartphone } from 'lucide-react';
import { TwinProfile, CyberScenario } from '../types';
import { SIMULATED_SCENARIOS, MOCK_THREAT_FEED_LOGS } from '../data';

interface DashboardProps {
  profile: TwinProfile;
  blockedCount: number;
  onSetTab: (tab: string) => void;
}

export default function AegisXDashboard({ profile, blockedCount, onSetTab }: DashboardProps) {
  // Scenario Trainer game states
  const [currentScenarioIdx, setCurrentScenarioIdx] = useState(0);
  const [score, setScore] = useState(72); // Starts at 72
  const [solvedCount, setSolvedCount] = useState(0);
  const [userFeedback, setUserFeedback] = useState<{
    status: 'correct' | 'incorrect' | null;
    message: string;
  }>({ status: null, message: '' });
  const [shieldActive, setShieldActive] = useState(true);

  // Selected scenario
  const scenario = SIMULATED_SCENARIOS[currentScenarioIdx];

  const handleScenarioAction = (action: 'TRUST' | 'BLOCK') => {
    if (userFeedback.status !== null) return; // Prevent double trigger

    const isCorrect = action === scenario.correctAction;
    const pointWorth = scenario.points;

    if (isCorrect) {
      setScore(prev => Math.min(prev + 4, 100)); // Boost overall synergy
      setSolvedCount(prev => prev + 1);
      setUserFeedback({
        status: 'correct',
        message: `Excellent! You successfully neutralized the threat. Your Digital Twin processed the outcome and boosted your defensive synergy! Point delta: +${pointWorth}.`
      });
    } else {
      setScore(prev => Math.max(prev - 6, 20)); // Reduce overall synergy
      setUserFeedback({
        status: 'incorrect',
        message: `Threat Triggered! Careful: ${scenario.scamExplanation} Your customized twin absorbed the risk and re-calibrated your defenses.`
      });
    }
  };

  const handleNextScenario = () => {
    setUserFeedback({ status: null, message: '' });
    setCurrentScenarioIdx((currentScenarioIdx + 1) % SIMULATED_SCENARIOS.length);
  };

  const activeVulnerabilitiesCount = profile.concerns.length || 3;

  return (
    <div className="p-4 md:p-8 space-y-8" id="dashboard-wrapper">
      {/* Dynamic Header Badge and Toggle */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-zinc-950/60 border border-zinc-900 p-6 rounded-3xl shadow-lg relative overflow-hidden" id="dashboard-banner">
        {/* Decorative Grid Mesh */}
        <div className="absolute inset-0 opacity-[0.03] bg-[radial-gradient(#3b82f6_1px,transparent_1px)] [background-size:16px_16px] pointer-events-none" />

        <div className="flex items-start space-x-3.5 relative z-10">
          <div className="w-11 h-11 rounded-xl bg-blue-600/10 flex items-center justify-center border border-blue-500/20 flex-shrink-0 shadow-[0_0_15px_rgba(59,130,246,0.1)]">
            <ShieldCheck className="w-6 h-6 text-blue-400 animate-pulse" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white font-sans tracking-tight">
              AegisX Cybersecurity Flight Deck
            </h2>
            <p className="text-zinc-400 text-xs mt-1 leading-normal">
              Autonomous Cybersecurity Twin is <span className="text-blue-400 font-semibold font-mono">ON-DUTY</span>. Calibrating behaviors for <span className="text-white font-semibold">{profile.occupation || 'User'}</span> profile nodes.
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-4 relative z-10">
          <span className="text-right flex flex-col hidden sm:block">
            <span className="text-[10px] font-mono text-zinc-500 uppercase font-semibold">Defensive Shields State</span>
            <span className={`text-xs font-mono font-bold tracking-wide uppercase ${shieldActive ? 'text-emerald-400' : 'text-rose-400'}`}>
              {shieldActive ? 'FULLY SYNCHRONIZED' : 'PROTECTION PAUSED'}
            </span>
          </span>
          <button
            onClick={() => setShieldActive(!shieldActive)}
            className={`px-4 py-2.5 text-xs font-semibold rounded-xl border transition-all cursor-pointer ${
              shieldActive
                ? 'bg-blue-600/10 border-blue-500/30 hover:bg-blue-600/20 text-blue-400'
                : 'bg-rose-950/20 border-rose-900/40 hover:bg-rose-950/40 text-rose-300'
            }`}
          >
            {shieldActive ? 'Pause Active Protection' : 'Resume Protection'}
          </button>
        </div>
      </div>

      {/* Top Section Layout: Neural Mesh Graphic + Stats */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* LEFT COMPONENT: Beautiful neural mesh visual */}
        <div className="lg:col-span-5 bg-zinc-900/30 border border-zinc-900 rounded-3xl p-6 flex flex-col items-center justify-center pb-8" id="mesh-visual-container">
          {/* Neural Mesh Design */}
          <div className="relative w-56 h-56 flex items-center justify-center mt-4">
            <div className="absolute inset-0 border-[1px] border-blue-500/20 rounded-full animate-pulse"></div>
            <div className="absolute inset-4 border-[1px] border-blue-500/40 rounded-full"></div>
            <div className="absolute inset-8 border-[2px] border-blue-500 rounded-full flex items-center justify-center bg-blue-500/5 shadow-[0_0_50px_rgba(59,130,246,0.15)]">
              <div className="text-center">
                <p className="text-4xl font-light text-white font-sans">{score}%</p>
                <p className="text-[10px] uppercase tracking-widest text-blue-400 mt-1">Accuracy Synergy</p>
              </div>
            </div>
            {/* Orbital dots */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1 w-2.5 h-2.5 bg-blue-400 rounded-full shadow-[0_0_12px_#60a5fa] animate-[spin_10s_linear_infinite]"></div>
            <div className="absolute bottom-10 right-0 w-2.5 h-2.5 bg-emerald-400 rounded-full shadow-[0_0_12px_#34d399]"></div>
          </div>

          <div className="mt-8 text-center">
            <h3 className="text-md font-medium text-white">Digital Twin Mesh Active</h3>
            <p className="text-zinc-500 text-xs mt-1.5 max-w-xs leading-relaxed">
              Continuously syncing your digital signatures across <span className="text-blue-400 font-semibold font-mono">14 connected channels</span>.
            </p>
          </div>

          {/* Quick Stats Block inside visual */}
          <div className="grid grid-cols-2 gap-3 w-full mt-6">
            <div className="bg-zinc-800/40 p-3.5 rounded-2xl border border-white/5 text-center">
              <p className="text-zinc-500 text-[9px] uppercase tracking-wider">Blocked Threats</p>
              <p className="text-xl font-mono text-white mt-1 leading-none">{blockedCount + 1248}</p>
            </div>
            <div className="bg-zinc-800/40 p-3.5 rounded-2xl border border-white/5 text-center">
              <p className="text-zinc-500 text-[9px] uppercase tracking-wider">Vulnerabilities Locked</p>
              <p className="text-xl font-mono text-white mt-1 leading-none">{SIMULATED_SCENARIOS.length - solvedCount}</p>
            </div>
          </div>
        </div>

        {/* RIGHT COMPONENT: Key Statistics Grid of Flight Deck */}
        <div className="lg:col-span-7 grid grid-cols-2 gap-4">
          {/* Threats blocks tracker */}
          <div className="bg-zinc-900/50 border border-zinc-900 p-5 rounded-3xl flex flex-col justify-between">
            <div>
              <span className="block text-[10px] font-mono uppercase tracking-wider text-zinc-500">Threats Neutralized</span>
              <span className="text-3xl font-bold text-white font-mono block mt-2">{blockedCount + 14}</span>
            </div>
            <p className="text-[10px] text-zinc-400 mt-4 leading-relaxed">Malicious emails and voice phishes blocked automatically.</p>
          </div>

          {/* Security level badge */}
          <div className="bg-zinc-900/50 border border-zinc-900 p-5 rounded-3xl flex flex-col justify-between">
            <div>
              <span className="block text-[10px] font-mono uppercase tracking-wider text-zinc-500">Continuous Training</span>
              <span className="text-3xl font-bold text-white font-mono block mt-2">{solvedCount} / {SIMULATED_SCENARIOS.length}</span>
            </div>
            <p className="text-[10px] text-zinc-400 mt-4 leading-relaxed">Simulated zero-day training scenarios successfully solved.</p>
          </div>

          {/* Target vectors analyzed */}
          <div className="bg-zinc-900/50 border border-zinc-900 p-5 rounded-3xl flex flex-col justify-between">
            <div>
              <span className="block text-[10px] font-mono uppercase tracking-wider text-zinc-500">Shielded Channels</span>
              <span className="text-2xl font-bold text-blue-400 font-mono block mt-2">{profile.devices.length || 3} Secured</span>
            </div>
            <p className="text-[10px] text-zinc-400 mt-4 leading-relaxed">Monitored device endpoints status: High Protection Enabled.</p>
          </div>

          {/* Synergy Badge detail */}
          <div className="bg-gradient-to-br from-blue-600/10 to-indigo-600/15 border border-blue-500/20 p-5 rounded-3xl flex flex-col justify-between">
            <div>
              <span className="block text-[10px] font-mono uppercase tracking-wider text-blue-400 font-semibold">Defensive Synergy Index</span>
              <span className="text-3xl font-bold text-white font-mono block mt-2">{score}%</span>
            </div>
            <span className="text-[10px] text-blue-300 flex items-center gap-1 mt-4 font-mono">
              <Zap className="w-3.5 h-3.5 text-blue-400 animate-bounce" />
              {score > 80 ? 'Optimal Co-immunity Stable' : 'Action calibrated training needed'}
            </span>
          </div>
        </div>
      </div>

      {/* Main interactive bottom modules */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* LEFT COLUMN: Scenario simulator Trainer Game */}
        <div className="lg:col-span-8 bg-zinc-900/50 border border-zinc-900 rounded-3xl p-6 shadow-xl space-y-4" id="scenario-trainer-panel">
          <div className="flex items-center justify-between border-b border-zinc-800/80 pb-3">
            <div className="flex items-center space-x-2">
              <BookOpen className="w-4 h-4 text-blue-400" />
              <h3 className="text-xs font-bold font-mono tracking-wider uppercase text-zinc-300">
                AegisX Security Scenario Trainer
              </h3>
            </div>
            <div className="flex items-center space-x-2">
              <span className="text-[9px] font-mono uppercase bg-zinc-950 text-zinc-400 border border-zinc-900 px-2 py-0.5 rounded">
                Difficulty: {scenario.difficulty}
              </span>
              <span className="text-[9px] font-mono uppercase bg-blue-500/10 text-blue-400 border border-blue-500/20 px-2 py-0.5 rounded">
                {scenario.category}
              </span>
            </div>
          </div>

          {/* Scenario description */}
          <div className="bg-zinc-950 p-4 rounded-2xl border border-zinc-800/60 space-y-3.5 relative">
            <div className="flex items-center justify-between text-[10px] font-mono text-zinc-500">
              <span className="font-semibold text-blue-400">INTERCEPTED INTERACTIVE TARGET (CLASSIFICATION: {scenario.contentType})</span>
              <span>Scenario {currentScenarioIdx + 1} of {SIMULATED_SCENARIOS.length}</span>
            </div>
            
            <p className="text-xs text-zinc-300 italic leading-relaxed font-sans bg-zinc-900/50 p-4 rounded-xl border border-zinc-800/40 break-words select-all">
              "{scenario.content}"
            </p>
          </div>

          {/* Correct/Incorrect feedback */}
          {userFeedback.status && (
            <div className={`p-4 rounded-xl border flex items-start space-x-3 transition-all ${
              userFeedback.status === 'correct'
                ? 'bg-emerald-950/20 border-emerald-950/65 text-emerald-400'
                : 'bg-rose-950/20 border-rose-950/65 text-rose-300'
            }`}>
              <div className="mt-0.5">
                {userFeedback.status === 'correct' ? (
                  <ShieldCheck className="w-5 h-5 text-emerald-400" />
                ) : (
                  <AlertCircle className="w-5 h-5 text-rose-500 animate-pulse" />
                )}
              </div>
              <div className="space-y-1.5 flex-1 text-xs">
                <span className="font-bold uppercase tracking-wider block font-mono">
                  {userFeedback.status === 'correct' ? 'Mitigation Successful!' : 'Security Boundary Compromised!'}
                </span>
                <p className="leading-relaxed font-sans">{userFeedback.message}</p>
                <button
                  onClick={handleNextScenario}
                  className="mt-2 bg-gradient-to-r from-blue-600/25 to-indigo-600/25 border border-blue-500/30 text-white font-semibold px-4 py-2 rounded-xl text-[10px] uppercase font-mono tracking-wider transition-all cursor-pointer hover:border-blue-500/50"
                >
                  Load Next Intercepted Payload
                </button>
              </div>
            </div>
          )}

          {/* Options for action */}
          {!userFeedback.status && (
            <div className="grid grid-cols-2 gap-4 pt-2" id="action-buttons-box">
              <button
                onClick={() => handleScenarioAction('TRUST')}
                className="flex items-center justify-center space-x-2 bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold text-xs py-3 px-4 rounded-xl transition-all cursor-pointer active:scale-95 border-b-2 border-emerald-800"
              >
                <Check className="w-4 h-4" />
                <span>TRUST & PROCEED</span>
              </button>
              <button
                onClick={() => handleScenarioAction('BLOCK')}
                className="flex items-center justify-center space-x-2 bg-[#050505] hover:bg-zinc-800 text-white border border-rose-500/40 font-bold text-xs py-3 px-4 rounded-xl transition-all cursor-pointer active:scale-95"
              >
                <X className="w-4 h-4 text-rose-400" />
                <span>BLOCK & MITIGATE</span>
              </button>
            </div>
          )}

          <p className="text-[10px] text-zinc-500 italic mt-2 text-center leading-relaxed">
            *This trainer gamifies potential exploits. Build real-world response actions to elevate your defense model synergy!
          </p>
        </div>

        {/* RIGHT COLUMN: Defensive actions suggestions and live logs */}
        <div className="lg:col-span-4 space-y-6" id="dashboard-right-sidebar">
          {/* Quick Context Adaptive Safeguards */}
          <div className="bg-zinc-900/50 border border-zinc-900 rounded-3xl p-6 shadow-xl space-y-4" id="adaptive-safeguards-card">
            <span className="block text-[10px] font-mono uppercase tracking-wider text-zinc-400 font-bold">
              Dynamic Guard Directives
            </span>

            <div className="space-y-3">
              <div className="flex items-start space-x-3">
                <div className="w-5 h-5 rounded bg-blue-500/10 flex items-center justify-center border border-blue-500/20 mt-0.5 flex-shrink-0">
                  <Zap className="w-3.5 h-3.5 text-blue-400" />
                </div>
                <div>
                  <span className="text-xs text-white font-semibold block leading-tight">Zero-Day Immunization</span>
                  <span className="text-[10px] text-zinc-400 leading-normal block mt-1">
                    Your Digital Twin tracks {activeVulnerabilitiesCount} concerns. Run simulated emails inside the <button onClick={() => onSetTab('phishing')} className="text-blue-400 font-semibold hover:underline">Auditor tool</button>.
                  </span>
                </div>
              </div>

              <div className="flex items-start space-x-3">
                <div className="w-5 h-5 rounded bg-blue-500/10 flex items-center justify-center border border-blue-500/20 mt-0.5 flex-shrink-0">
                  <Smartphone className="w-3.5 h-3.5 text-blue-400" />
                </div>
                <div>
                  <span className="text-xs text-white font-semibold block leading-tight">Devices Nodes Setup</span>
                  <span className="text-[10px] text-zinc-400 leading-normal block mt-1">
                    {profile.devices.length ? `${profile.devices.length} verified devices secured.` : 'Configure connected phones'} Inside the <button onClick={() => onSetTab('setup')} className="text-blue-400 font-semibold hover:underline">Twin setup module</button>.
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Active Terminal feed */}
          <div className="bg-zinc-950 border border-zinc-900 rounded-3xl p-6 shadow-xl space-y-4" id="dashboard-live-terminal">
            <div className="flex justify-between items-center pb-2 border-b border-zinc-900">
              <span className="text-[10px] font-mono tracking-wider uppercase text-zinc-400 font-bold">AegisX Live Watch</span>
              <span className="px-2 py-0.5 bg-blue-500/15 text-blue-400 text-[9px] font-bold rounded uppercase animate-pulse">Scanning...</span>
            </div>

            <div className="space-y-3.5 max-h-[190px] overflow-y-auto font-mono text-[10px] text-zinc-400 pr-1 leading-relaxed">
              {MOCK_THREAT_FEED_LOGS.map((log) => (
                <div key={log.id} className="border-b border-zinc-900/60 pb-2.5 last:border-none last:pb-0">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-zinc-600 font-light">{log.time}</span>
                    <span className={`text-[8px] tracking-wide border px-1.5 py-0.5 rounded uppercase ${
                      log.severity === 'High' ? 'text-rose-400 border-rose-500/10 bg-rose-500/5' :
                      log.severity === 'Medium' ? 'text-amber-400 border-amber-500/10 bg-amber-500/5' :
                      'text-zinc-400 border-zinc-800 bg-zinc-950'
                    }`}>
                      {log.severity}
                    </span>
                  </div>
                  <p className="text-zinc-300 mt-1">{log.event}</p>
                  <p className="text-blue-400 text-[9px] mt-0.5 font-bold">⇒ {log.action}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
