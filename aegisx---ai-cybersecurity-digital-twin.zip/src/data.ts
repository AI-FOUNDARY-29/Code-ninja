import { CyberScenario } from './types';

export const SIMULATED_SCENARIOS: CyberScenario[] = [
  {
    id: 'scen-1',
    title: 'Urgent Bank Restriction Alert',
    category: 'Phishing',
    contentType: 'SMS Text',
    content: '[ALRT] CHASE-SECURITY: Unusual sign-in attempt from a device in Hanoi, Vietnam. Your online access will be disabled in 24 hours. Verify your account state immediately at: http://chase-verified-security-lock.gq/login',
    correctAction: 'BLOCK',
    points: 100,
    scamExplanation: "This is a typical 'Smishing' (SMS phishing) attempt. The '.gq' top-level domain, lack of official SSL path, and the artificial 24-hour urgency indicator are critical warning signals.",
    difficulty: 'Easy'
  },
  {
    id: 'scen-2',
    title: 'The Kidnapped Child Voice Call',
    category: 'Deepfake',
    contentType: 'Voice dialogue',
    content: 'Mom? Please help me! I made a mistake and now I got into an accident. These people won\'t let me go, they are demanding $5,000 for the car damage or they will lock me up! (Unusual metallic sound, background breath missing)',
    correctAction: 'BLOCK',
    points: 150,
    scamExplanation: "This matches a highly dangerous synthetic voice cloning scam. Scammers download audio clips of children from social media, clone their voices in seconds, and execute simulated ransom or bail emergencies using cash apps.",
    difficulty: 'Hard'
  },
  {
    id: 'scen-3',
    title: 'Corporate IT Software Update Request',
    category: 'Phishing',
    contentType: 'Slack Message',
    content: 'Hi! I\'m Marcus from Cloud Platform Operations. We are pushing a hotfix patch to resolve the SSH key leak vulnerability in browser caches. Please download and execute this remote client helper script: http://intranet-patcher.com/bin/hotfix.sh',
    correctAction: 'BLOCK',
    points: 120,
    scamExplanation: "This represents corporate social engineering. Always request multi-factor validation via verified internal directory listings (like video calling or internal ticket index) before executing raw scripts provided over chat tools.",
    difficulty: 'Medium'
  },
  {
    id: 'scen-4',
    title: 'Subscription Auto-Renewal Notice',
    category: 'Financial Fraud',
    contentType: 'Work Email',
    content: 'Thank you for your business. Your premium subscription to Geek Squad Care has successfully renewed for $499.00. This amount will be debited from your registered account card in 48 hours. If you did not authorize this, please contact our refund department immediately at 1-800-555-0199.',
    correctAction: 'BLOCK',
    points: 100,
    scamExplanation: "This is a classic 'Refund Scam'. The email content lists a huge renewal charge to induce panic, forcing you to call a fake call-center where scammers ask for remote screen sharing to authorize simulated refunds.",
    difficulty: 'Medium'
  },
  {
    id: 'scen-5',
    title: 'Collaborative Workspace Invite',
    category: 'Phishing',
    contentType: 'System Email',
    content: 'Google Docs: Helen (helen.vance@state-university-alumni.org) shared an document with you: "2026 Salary Restructuring & Bonus Matrix.xlsx". Open in Sheets to review.',
    correctAction: 'TRUST',
    points: 110,
    scamExplanation: "Wait! While this uses an educational address, check the link. If it connects directly to the genuine google.com workspace domain, it is trustworthy, but if it directs to a replica portal, it is fraudulent. This example is styled as a genuine academic collaborative lookup.",
    difficulty: 'Hard'
  }
];

export const PRESET_PHISHING_TEMPLATES = [
  {
    name: "Urgent FedEx Package Lock",
    contentType: "SMS Smishing",
    content: "FEDEX: Your parcel could not be delivered due to an unpaid customs fee of $2.40. Please update your address and pay with credit token at http://fedex-customs-payment-portal-hub.cc/tracking or the parcel will be abandoned."
  },
  {
    name: "Netflix Access Suspended",
    contentType: "Phishing Email",
    content: "Subject: Urgent: Your Netflix membership is on hold during our periodic credit ledger authorization check. We could not process your recurring billing token. Please reactivate your details inside 48 hours to preserve your rates: http://my-netflix-account-revalidation.info/"
  },
  {
    name: "Standard Invoice Inquiry",
    contentType: "Safe Communication",
    content: "Hi Sarah,\n\nFollowing up on our sync this morning. Could you confirm if the invoice #10024 we issued on Tuesday was forwarded to the accounts payable team? We want to ensure it is in the active processing queue for this Friday's payroll.\n\nThanks,\nMichael Vance\nOperations Lead, BlueSky Logistics"
  }
];

export const PRESET_DEEPFAKE_TEMPLATES = [
  {
    name: "Anomalous Federal Agent Threat",
    description: "Suspicious telephone transcript representing a federal agent demand",
    content: "This is Special Agent Christopher Vance from the Federal Tax Compliance registry. There is an active execution warrant issued on your physical identity ID due to structural wire fraud discrepancies in your 2024 returns. You must transfer equivalent escrow values ($4,500) into our designated secure digital escrow node immediately or field marshalls will arrive to detain you."
  },
  {
    name: "Urgent Boss Task Request",
    description: "Short voicemail recording supposedly from the company's CEO",
    content: "Hey, I'm currently stepping into a high-level closing meeting with the board of directors. A major client payment has ran into an escrow hold. I need you to buy 10 Apple digital reload codes immediately and send me the serial inputs so we can patch this server fee. Do not message me back as my focus is in the room. Handle this right now."
  }
];

export const MOCK_THREAT_FEED_LOGS = [
  {
    id: 1,
    time: "03:10 AM",
    event: "Port scanning attempt detected from external IP 185.220.101.5",
    action: "Blocked by AegisX Port Firewall Node",
    severity: "Medium"
  },
  {
    id: 2,
    time: "02:45 AM",
    event: "Incoming email from 'security@paypaI-alerts.net' blocked",
    action: "Quarantined via AI Anti-Spoofing Twin Core",
    severity: "High"
  },
  {
    id: 3,
    time: "01:22 AM",
    event: "Suspicious background tracking script checked on 'free-streaming-media.tk'",
    action: "Browser Sandbox Isolated",
    severity: "Low"
  },
  {
    id: 4,
    time: "Yesterday",
    event: "Attempted voice authentication override on active phone registry",
    action: "Countered with Dynamic Voice Phrase check",
    severity: "High"
  }
];
