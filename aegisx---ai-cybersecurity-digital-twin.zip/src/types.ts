export interface TwinProfile {
  age: string;
  occupation: string;
  techSavviness: 'Basic (Low)' | 'Moderate' | 'Advanced (Tech Person)';
  devices: string[];
  concerns: string[];
}

export interface ThreatAnalysis {
  threatScore: number;
  riskTier: 'SAFE' | 'SUSPICIOUS' | 'CRITICAL';
  threatType: string;
  riskSummary: string;
  redFlags: string[];
  actionableAdvice: string[];
  educationalConcept: string;
}

export interface DeepfakeAnalysis {
  deepfakeProbability: number;
  cloningIndicators: string[];
  scamLikelihood: 'HIGH' | 'MEDIUM' | 'LOW';
  coercionTacticsSpotted: string[];
  verificationCountersteps: string[];
}

export interface BreachRecord {
  breachName: string;
  date: string;
  compromisedData: string[];
}

export interface LeakScanResult {
  exposureSeverity: 'SECURE' | 'LOW' | 'MODERATE' | 'CRITICAL';
  breachesSpotted: BreachRecord[];
  darkWebPrevalence: number;
  securityRecommendations: string[];
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'twin';
  text: string;
  timestamp: string;
}

export interface CyberScenario {
  id: string;
  title: string;
  category: 'Phishing' | 'Deepfake' | 'Financial Fraud' | 'SMS Smishing';
  contentType: string; // e.g. "SMS", "Work Email", "Phone Call"
  content: string;
  correctAction: 'TRUST' | 'BLOCK';
  points: number;
  scamExplanation: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
}
