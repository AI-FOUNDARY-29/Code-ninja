import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  UserCog, 
  ShieldAlert, 
  Radio, 
  Eye, 
  MessageSquare, 
  LayoutDashboard, 
  Lock,
  Menu,
  X,
  Sparkles,
  Zap,
  Bot
} from 'lucide-react';
import { TwinProfile } from './types';

// Importing Custom Sub-components
import AegisXDashboard from './components/AegisXDashboard';
import TwinProfileSetup from './components/TwinProfileSetup';
import PhishingAnalyzer from './components/PhishingAnalyzer';
import DeepfakeScamAuditor from './components/DeepfakeScamAuditor';
import DarkWebMonitor from './components/DarkWebMonitor';
import TwinCoachChat from './components/TwinCoachChat';

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [theme, setTheme] = useState(() => {
    return localStorage.getItem('aegisx-theme') || 'deepspace';
  });

  useEffect(() => {
    const root = document.documentElement;
    root.classList.remove('theme-deepspace', 'theme-highcontrast', 'theme-light');
    root.classList.add(`theme-${theme}`);
    localStorage.setItem('aegisx-theme', theme);
  }, [theme]);

  // Core App states
  const [twinProfile, setTwinProfile] = useState<TwinProfile>({
    age: '28',
    occupation: 'Professional and Online Shopper',
    techSavviness: 'Moderate',
    devices: ['Android Phone (Google)', 'Google Chrome / Edge', 'Windows Laptop/Desktop'],
    concerns: ['Phishing Emails / Smishing Messages', 'Voice Cloning & Call Scams']
  });

  const [blockedCount, setBlockedCount] = useState(0);

  const handleBlockedThreat = (type: string, score: number) => {
    // Record threat detected & blocked safely
    setBlockedCount(prev => prev + 1);
  };

  const menuItems = [
    { id: 'dashboard', name: 'AegisX Cockpit', icon: LayoutDashboard, description: 'Synergy Score & Scenario Trainer' },
    { id: 'setup', name: 'AI Digital Twin Setup', icon: UserCog, description: 'Configure custom profiling details' },
    { id: 'phishing', name: 'Zero-Day Scam Auditor', icon: ShieldAlert, description: 'Scan suspicious emails & SMS links' },
    { id: 'deepfake', name: 'Deepfake Voice Auditor', icon: Radio, description: 'Verify cloned voice caller risks' },
    { id: 'leak', name: 'Dark Web Leak Monitor', icon: Eye, description: 'Audit exposed credentials' },
    { id: 'chat', name: 'Twin Guard Companion', icon: MessageSquare, description: 'Direct consultation chat core' }
  ];

  return (
    <div className={`bg-zinc-950 text-zinc-200 min-h-screen font-sans flex flex-col md:flex-row relative theme-${theme}`} id="aegisx-application-core">
      {/* Dynamic Background Cyber Mesh Overlay */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#18181b_1px,transparent_1px),linear-gradient(to_bottom,#18181b_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] opacity-40 pointer-events-none" />

      {/* MOBILE HEADER BAR */}
      <header className="md:hidden bg-zinc-950 border-b border-zinc-900 p-4 flex items-center justify-between relative z-50 flex-shrink-0">
        <div className="flex items-center space-x-2.5">
          <div className="w-8 h-8 rounded-lg bg-blue-600/10 flex items-center justify-center border border-blue-500/20">
            <ShieldCheck className="w-5 h-5 text-blue-400" />
          </div>
          <span className="font-extrabold text-sm tracking-tight text-white font-sans">
            AEGIS<span className="text-blue-500">X</span>
          </span>
        </div>
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="text-zinc-400 hover:text-white focus:outline-none focus:ring-1 focus:ring-zinc-800 p-1.5 rounded-lg border border-zinc-800 bg-zinc-950/40"
        >
          {mobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
        </button>
      </header>

      {/* RESPONSIVE LEFT SIDE NAVIGATION MENU */}
      <aside className={`
        fixed inset-y-0 left-0 w-64 bg-zinc-950 md:bg-zinc-950/60 border-r border-zinc-900 p-5 flex flex-col justify-between z-40 transform transition-transform duration-300 md:relative md:translate-x-0
        ${mobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}
      `} id="navigation-sidebar">
        
        <div className="space-y-6">
          {/* Brand Identity / Desktop header */}
          <div className="hidden md:flex items-center space-x-3 pb-4 border-b border-zinc-900">
            <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center shadow-[0_0_15px_rgba(37,99,235,0.3)]">
              <div className="w-5 h-5 border-2 border-white rounded-full relative">
                <div className="absolute inset-1 bg-white rounded-full"></div>
              </div>
            </div>
            <div>
              <h1 className="text-xl font-bold text-white tracking-tight leading-none">AEGIS<span className="text-blue-500">X</span></h1>
              <span className="text-[9px] font-mono uppercase tracking-[0.15em] text-blue-400 font-bold block mt-1">
                AUTONOMOUS DIGITAL TWIN
              </span>
            </div>
          </div>

          {/* Menu Items Loop */}
          <nav className="space-y-1.5" id="nav-items-block">
            {menuItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`
                    w-full flex items-center space-x-3.5 px-3.5 py-3 rounded-xl text-left transition-all relative group cursor-pointer
                    ${isActive 
                      ? 'bg-blue-500/10 border border-blue-500/20 text-blue-400 shadow-[0_0_15px_rgba(59,130,246,0.05)]' 
                      : 'border border-transparent text-zinc-500 hover:text-zinc-200 hover:bg-zinc-900/40'
                    }
                  `}
                >
                  {/* Active highlight pill */}
                  {isActive && <div className="absolute left-0 top-3 bottom-3 w-1 bg-blue-500 rounded-r-md" />}
                  
                  <Icon className={`w-4 h-4 flex-shrink-0 ${isActive ? 'text-blue-400' : 'text-zinc-500 group-hover:text-zinc-200'}`} />
                  <div>
                    <span className="block text-xs font-semibold leading-tight font-sans">{item.name}</span>
                    <span className="block text-[9px] text-zinc-600 leading-tight truncate group-hover:text-zinc-500 font-sans mt-0.5">{item.description}</span>
                  </div>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Quick theme control picker */}
        <div className="pt-4 border-t border-zinc-900/60 mt-4" id="sidebar-theme-picker">
          <span className="block text-[8px] font-mono text-zinc-500 uppercase font-bold mb-2 tracking-wider">ACCESSIBILITY DISPLAY THEME</span>
          <div className="grid grid-cols-3 gap-1 bg-zinc-900/40 p-1 rounded-xl border border-zinc-900">
            {(['deepspace', 'highcontrast', 'light'] as const).map((t) => (
              <button
                key={t}
                onClick={() => setTheme(t)}
                className={`text-[9px] font-mono py-1.5 rounded-lg transition-all font-bold cursor-pointer text-center ${
                  theme === t
                    ? 'bg-blue-600 border border-blue-500 text-white shadow-md'
                    : 'bg-transparent border border-transparent text-zinc-500 hover:text-zinc-300'
                }`}
              >
                {t === 'deepspace' ? 'Space' : t === 'highcontrast' ? 'A11y' : 'Light'}
              </button>
            ))}
          </div>
        </div>

        {/* Small footer system status */}
        <div className="pt-3 border-t border-zinc-900/60 mt-3" id="sidebar-footer">
          <div className="bg-zinc-900/40 rounded-xl p-2.5 border border-zinc-800/40 flex items-center space-x-2.5">
            <div className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_8px_#10b981] animate-pulse flex-shrink-0" />
            <div>
              <span className="block text-[8px] font-mono text-zinc-500 uppercase font-bold">SHIELD STATUS</span>
              <span className="block text-[9px] font-mono text-emerald-400 font-semibold uppercase">FULLY SYNCHRONIZED</span>
            </div>
          </div>
        </div>

      </aside>

      {/* MAIN LAYOUT CANVAS */}
      <main className="flex-1 overflow-y-auto relative z-20" id="main-route-canvas">
        {/* Render correct page viewport */}
        {activeTab === 'dashboard' && (
          <AegisXDashboard 
            profile={twinProfile} 
            blockedCount={blockedCount} 
            onSetTab={(tab) => {
              setActiveTab(tab);
            }} 
          />
        )}

        {activeTab === 'setup' && (
          <TwinProfileSetup 
            profile={twinProfile} 
            onUpdate={(updated) => setTwinProfile(updated)} 
            theme={theme}
            onSetTheme={setTheme}
          />
        )}

        {activeTab === 'phishing' && (
          <PhishingAnalyzer 
            onBlockedThreat={handleBlockedThreat} 
          />
        )}

        {activeTab === 'deepfake' && (
          <DeepfakeScamAuditor 
            onBlockedThreat={handleBlockedThreat} 
          />
        )}

        {activeTab === 'leak' && (
          <DarkWebMonitor />
        )}

        {activeTab === 'chat' && (
          <TwinCoachChat 
            twinProfile={twinProfile} 
          />
        )}
      </main>
    </div>
  );
}
